package com.example.kraken_ble_control

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
